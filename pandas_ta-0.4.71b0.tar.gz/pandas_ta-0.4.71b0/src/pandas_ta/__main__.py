#-*- coding: utf-8 -*-
from pandas_ta import version

SUPPORT="http://www.pandas-ta.dev/support"

if __name__ == "__main__":
    print(f"Pandas TA: {version}\nSupport: {SUPPORT}")
